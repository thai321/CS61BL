import java.util.*;
import java.io.*;
public class Checker {
	private String goal;
	private HashMap<Coordinate, Block> blocks;
	private HashSet<Coordinate> goals;
	private Coordinate[][] board;
	private HashSet<Block> allBlocks;
	public boolean win;

	public Checker(){
		// initialToGoal = new HashMap<Block, Block>();
		allBlocks = new HashSet<Block>();
		board = new Coordinate[9][9];
		blocks = new HashMap<Coordinate,Block>();
		goals = new HashSet<Coordinate>();

	}
	public Checker(String init) {
		Tray thai = new Tray(init);
		win = false;
	}
	public Checker copy(Checker other, int x_top, int y_top, int x_to, int y_to) {
		// System.out.println("NULL???");
		this.board = new Coordinate[other.getBoard().length][other.getBoard()[0].length];
		// System.out.println("NULL???");
		this.blocks = new HashMap<Coordinate, Block>();
		this.allBlocks = new HashSet<Block>(other.getAllBlocks());
		for(int i = 0; i < other.getBoard().length; i++) {
			for(int j = 0; j < other.getBoard()[0].length; j++) {
				this.board[i][j] = new Coordinate(i,j,other.getBoard()[i][j].getName().substring(0,1));

				if(this.board[i][j].isOccupied()) {
					// System.out.println("other size of the blocks = " + other.getBlocks().size());
					Block bl = other.getBlocks().get(other.getBoard()[i][j]);
					// System.out.println("bl == == == = " + other.getBoard()[i][j]);
					Block bl2 = new Block(bl.getTop(), bl.getBottom(), bl.getName().substring(0,1));
					// System.out.println("herehrehrehrehrehr");
					// System.out.println(x_top + " " + y_top + " " + x_to + " " + y_to);
					System.out.println(this.board[i][j]);
					this.blocks.put(this.board[i][j], bl2);
				}
			}
		}
		System.out.println(x_top + " " + y_top + " " + x_to + " " + y_to);
		// this.allBlocks = other.
		System.out.println(this.board[x_to][y_to].getName());
		// this.board[x_to][y_to] = new  Coordinate(x_to,y_to,"0");
		// System.out.println("null?  = "+ this.board[x_to][y_to].getName());
		// System.out.println("null?  = "+ this.board[x_top][y_top]);
		this.blocks.get(this.board[x_top][y_top]).move(this.board[x_to][y_to]);
		// System.out.println(x_top + " " + y_top + " " + x_to + " " + y_to);
		// if(x_top != 0 && y_top != 0 && x_to != 1 && y_to != 0) {
		// 	System.exit(1);
		// }
			
		return this;
	}

	public Coordinate[][] getBoard() {
		return board;
	}
	public HashMap<Coordinate, Block> getBlocks() {
		return blocks;
	}
	public HashSet<Block> getAllBlocks() {
		HashSet<Block> newAllBlocks = new HashSet<Block>();
		for (Coordinate key : blocks.keySet()) {
			// System.out.println("GET key set");
			if(!newAllBlocks.contains(blocks.get(key))) {
				newAllBlocks.add(blocks.get(key));
			}
		}
		return newAllBlocks;

	}



	public Checker(String initialConfiguration , String moveList, String goal) {

		exitFive(initialConfiguration, goal);

		this.goal = goal;
		Tray thai = new Tray(initialConfiguration);
		readGoal(goal);

	}
	public void exitFive(String initialConfiguration, String goal) {
		try {
				BufferedReader in = new BufferedReader(new FileReader(initialConfiguration));
				String current = "";
				int i = 0;
				int x ;
				int y ;
				int k ;
				int z ;
				while((current = in.readLine()) != null) { 

					String[] nums = current.split("\\s+");
					if(i == 0) {
						int n1 = Integer.parseInt(nums[0]);
						int n2 = Integer.parseInt(nums[1]);
						if(nums.length != 2 && (n2 <= 256 || n1 <= 256) ) {
							System.out.println("board dim Must be 2 integer");
							System.out.println("exit(5)");
							System.exit(5);
						}
						i = 1;
					}
					else if(nums.length != 4) {
						System.out.println("Tray, Must be 4 integer");
						System.out.println("exit(5)");
						System.exit(5);
					}
					for(int j = 0; j < nums.length ; j++) {
						try {
							int n = Integer.parseInt(nums[j]);
							if(n < 0 || n >=256) {
								System.out.println("Tray, number must be postive");
								System.out.println("exit(5)");
								System.exit(5);
							}
						} catch (NumberFormatException e) {
							System.out.println("Tray, not a number");
							System.out.println("exit(5)");
							System.exit(5);
						}
					}
				}
			
			}catch( IOException e) {
				System.err.println("Can't read the file");
				System.out.println("exit(3)");
				System.exit(3);
			}

			try {
				BufferedReader in = new BufferedReader(new FileReader(goal));
				String current = "";
				while((current = in.readLine()) != null) { 

					String[] nums = current.split("\\s+");
					if(nums.length != 4) {
						System.out.println("Tray, Must be 4 integer");
						System.out.println("exit(5)");
						System.exit(5);
					}
					for(int j = 0; j < nums.length ; j++) {
						try {
							int n = Integer.parseInt(nums[j]);
							if(n < 0 && n >= 256) {
								System.out.println("Tray, number must be postive");
								System.out.println("exit(5)");
								System.exit(5);
							}
						} catch (NumberFormatException e) {
							System.out.println("Tray, not a number");
							System.out.println("exit(5)");
							System.exit(5);
						}
					}
				}
			
			}catch( IOException e) {
				System.err.println("Can't read the file");
				System.out.println("exit(3)");
				System.exit(3);
			}
	}


	public void readGoal(String goal) {
		int x = 0;
		try {
			BufferedReader in = new BufferedReader(new FileReader(goal));
			goals = new HashSet<Coordinate>();
			String current = "";
			while((current = in.readLine()) != null) { 
				int i = Integer.parseInt(current.substring(0,1));
				int j = Integer.parseInt(current.substring(2,3));
				// System.out.println("i = " + i + "j = " + j);
				board[i][j].setGoal(current);
				// System.out.println("Goal = " + board[i][j]);
				goals.add(board[i][j]);
				// System.out.println(" getGoal = " + board[i][j].getGoal());
				if(board[i][j].isOccupied()) {
					if(blocks.get(board[i][j]).isGoal()) {
						x++;
					}
				}
			}
		}catch(IOException e) {
			System.out.println("Can't read the goal file");
			System.out.println("exit(3)");
			System.exit(3);
		}
		// System.out.println("Begin Goal size = " + goals.size());
		// System.out.println("x = " + x);
		if(goals.size() == x) {
			System.out.println("WIN MAN");
			System.out.println("exit(0)");
			System.exit(0);
		}
	}


	public void play() {
		print();
		Scanner in = new Scanner(System.in);
		// String temp = in.nextLine();
		while(in.hasNextLine()) { // check if is legal move later
			String temp = in.nextLine();
			String[] nums = temp.split("\\s+");
			// System.out.println("nums.length = " + nums.length);
			if(nums.length != 4) {
				System.out.println("Play, Must be 4 integer");
				System.out.println("exit(4)");
				System.exit(4);
			}
			for(int i = 0; i < 4 ; i++) {
				try {
					int n = Integer.parseInt(nums[i]);
					if(n < 0) {
						System.out.println("Play, number must be postive");
						System.out.println("exit(4)");
						System.exit(4);
					}
				} catch (NumberFormatException e) {
					System.out.println("Play, not a number");
					System.out.println("exit(4)");
					System.exit(4);
				}
			}

			int x = Integer.parseInt(nums[0]);
			int y = Integer.parseInt(nums[1]);
			int i = Integer.parseInt(nums[2]);
			int j = Integer.parseInt(nums[3]);
			boolean legal1 = (x == i) || (y == j);
			boolean legal2 = (i < board.length) && (j < board[0].length);
			boolean legal3 = (legal1 && legal2);

			if(!legal3 || !board[x][y].isOccupied()) {
				System.out.println("Contains an impossible move");
				System.out.println("exit(6)");
				System.exit(6);
			}

			blocks.get(board[x][y]).move(board[i][j]);
			print();
			// temp = in.nextLine();
		}
		if(!win) {
			System.out.println("the input moves do not solve the puzzle");
			System.out.println("exit(1)");
			System.exit(1);
		}
	}

	public void print(){
		System.out.println("blocks size  = " + blocks.size());
		for(int i = 0; i < board.length; i++){
			for(int j = 0; j < board[i].length; j++){
					System.out.print(board[i][j].getName() +  "  ");
			}
			System.out.println();
		}
	}

	
// ###################### MAIN ################################################################
	public static void main(String[] args){
		
		if(args.length != 2) {
			System.out.println("Must receive exactly 2 command lind inputs");
			System.out.println("exit(2)");
			System.exit(2);
		}
		Checker thai = new Checker(args[0],"",args[1]); 
		Scanner in = new Scanner(System.in);
		// int temp = in.nextInt();
		thai.play();

		

	}

// ###################### MAIN ################################################################


//--------------------Block------------------begin----------------------------------------
	public class Block {
		private String name; // for testing
		private Coordinate top_left;
		private Coordinate bottom_right;
		// private Block goal;

		public Block(){}

		public Block(Coordinate top_left, Coordinate bottom_right) {
			this.top_left = top_left;
			this.bottom_right = bottom_right;
			this.name = "0";
		}
		public Block(Coordinate top_left, Coordinate bottom_right, int i) {
			this.top_left = top_left;
			this.bottom_right = bottom_right;
			this.name = Integer.toString(i);;
		}
		public Block(Coordinate top_left, Coordinate bottom_right, String name) {
			this.top_left = top_left;
			this.bottom_right = bottom_right;
			this.name = name;
		}
		public Coordinate getTop() {
			return top_left;
		}
		public Coordinate getBottom() {
			return bottom_right;
		}

		/** 
		* @param takes a Coordinate that specifies where we want to try to move by trying to
		* move the block's top_left to toMoveTo
		* @return returns a boolean that says if we can make the move
		*/
		public boolean canMakeMove(Coordinate toMoveTo)  {  // 
			int k = 1;
			int x = toMoveTo.x;
			int y = toMoveTo.y;
			int x_length = Math.abs(this.top_left.x - this.bottom_right.x) + 1; 
			int y_length = Math.abs(this.top_left.y - this.bottom_right.y) + 1;
			if(x_length == 1|| y_length == 1) {
				k = 0;
			}
			int yDistance = Math.abs(this.top_left.y - toMoveTo.y);
			int xDistance = Math.abs(this.top_left.x - this.bottom_right.x);

			if(x < this.top_left.x) { //up
				System.out.println("up");
				for(int i = this.top_left.x - 1; i >= toMoveTo.x; i--) {
					for(int j = this.top_left.y; j <= this.bottom_right.y; j++) {
						System.out.println(board[i][j]);
						if(board[i][j].isOccupied()) {
							return false;
						}
					}
				}
				top(toMoveTo);
			}
			else if(x > this.top_left.x) { //down
				System.out.println("Down");
				for(int i = this.bottom_right.x + 1; i <= toMoveTo.x + xDistance && i < board.length; i++) {
					for(int j = this.top_left.y; j <= this.bottom_right.y; j++) {
						System.out.println(board[i][j]);
						if(board[i][j].isOccupied()) {
							return false;
						}
					}
				}
				bottom(toMoveTo);
			}
			else if(y < this.top_left.y) { //left
				System.out.println("left");
				for(int i = this.top_left.y - 1; i >= toMoveTo.y ; i--) {
					for(int j = this.top_left.x; j <= this.bottom_right.x; j++) {
						System.out.println(board[j][i]);
						if(board[j][i].isOccupied()) {
							return false;
						}
					}
				}
				left(toMoveTo);
			}
			else if(y > this.top_left.y) { //right
				System.out.println("right");
				for(int i = this.bottom_right.y + 1; i < toMoveTo.y + yDistance + k && i < board[0].length ; i++) {
					for(int j = this.bottom_right.x; j >= this.top_left.x; j--) {
						System.out.println(board[j][i]);
						if(board[j][i].isOccupied()) {
							return false;
						}
					}
				}
				right(toMoveTo);
				printBlocks();
			}
			toMoveTo.setName(this.name);
			toMoveTo.setOccupied(true);
			this.top_left = toMoveTo;
			// allBlocks.remove(board[this.top_left.getX()][this.top_left.getY()]);

			if(goals.contains(board[toMoveTo.x + x_length -1][toMoveTo.y + y_length - 1])) {
				board[toMoveTo.x + x_length -1][toMoveTo.y + y_length - 1].setOccupied(true);
				board[toMoveTo.x + x_length -1][toMoveTo.y + y_length - 1].setName(this.name);
				this.bottom_right = board[toMoveTo.x + x_length -1][toMoveTo.y + y_length - 1];
			}
			else {
				this.bottom_right = new Coordinate(toMoveTo.x + x_length -1, toMoveTo.y + y_length - 1, Integer.parseInt(this.name));
			}
			// this.bottom_right = new Coordinate(toMoveTo.x + x_length -1, toMoveTo.y + y_length - 1, Integer.parseInt(this.name));
			// allBlocks.remove()
			// allBlocks.add(this);
			return true;
		}

		public void top(Coordinate toMoveTo) {
			System.out.println("up update");
			int x_length = Math.abs(this.top_left.x - this.bottom_right.x) + 1; 
			int y_length = Math.abs(this.top_left.y - this.bottom_right.y) + 1;
			for(int i = this.top_left.x - 1; i >= toMoveTo.x; i--) {
				for(int j = this.top_left.y; j <= this.bottom_right.y; j++) {
					System.out.println(board[i][j]);
					// board[i][j] = new Coordinate(i,j,Integer.parseInt(this.name));
					if(goals.contains(board[i][j])) {
						board[i][j].setOccupied(true);
						board[i][j].setName(this.name);
					}
					else {
						board[i][j] = new Coordinate(i,j,Integer.parseInt(this.name));
					}
					blocks.put(board[i][j],this);
					blocks.remove(board[i + x_length][j]);
					// if(allBlocks.contains(board[i + x_length][j])) {
					// 	allBlocks.remove(board[i + x_length][j]);
					// }
					if(goals.contains(board[i + x_length][j])) {
						board[i + x_length][j].setOccupied(false);
						board[i + x_length][j].setName("0");
					}
					else {
						board[i + x_length][j] = new Coordinate(i + x_length, j, 0);
					}
				}
			}
			// allBlocks.add(this);

		}

		public void bottom(Coordinate toMoveTo) {
			int k = 1;
			System.out.println("Bottom update");
			int xDistance = Math.abs(this.top_left.x - this.bottom_right.x);
			int x_length = Math.abs(this.top_left.x - this.bottom_right.x) + 1; 
			if(x_length == 1) {
				k = 0;
			}
			for(int i = this.bottom_right.x + 1; i <= toMoveTo.x + xDistance   && i < board.length; i++) {
				for(int j = this.top_left.y; j <= this.bottom_right.y; j++) {
					System.out.println(board[i][j]);
					// System.out.println("true??? + " + goals.contains(board[3][1]));
					if(goals.contains(board[i][j])) {
						// System.out.println("Herer");
						board[i][j].setOccupied(true);
						board[i][j].setName(this.name);
					}
					else {
						board[i][j] = new Coordinate(i,j,Integer.parseInt(this.name));
					}
					// board[i][j] = new Coordinate(i,j,Integer.parseInt(this.name));
					blocks.put(board[i][j],this);
					blocks.remove(board[i - x_length][j]);
					if(goals.contains(board[i - x_length][j])) {
						// System.out.println("Herer222");
						board[i - x_length][j].setOccupied(false);
						board[i - x_length][j].setName("0");
					}
					else {
						board[i - x_length][j] = new Coordinate(i-x_length, j, 0);
					}
				}
			}
		}

		public void left(Coordinate toMoveTo) {
			System.out.println("left update");
			int y_length = Math.abs(this.top_left.y - this.bottom_right.y) + 1;
			for(int i = this.top_left.y - 1; i >= toMoveTo.y ; i--) {
				for(int j = this.top_left.x; j <= this.bottom_right.x; j++) {
					System.out.println(board[j][i]);
					// board[j][i] = new Coordinate(i,j,Integer.parseInt(this.name));
					if(goals.contains(board[j][i])) {
						board[j][i].setOccupied(true);
						board[j][i].setName(this.name);
					}
					else {
						board[j][i] = new Coordinate(j,i,Integer.parseInt(this.name));
					}
					blocks.put(board[j][i], this);
					blocks.remove(board[j][i + y_length]);
					if(goals.contains(board[j][i + y_length])) {
						board[j][i + y_length].setOccupied(false);
						board[j][i + y_length].setName("0");
					}
					else {
						board[j][i + y_length] = new Coordinate(j, i + y_length, 0);
					}
				}
			}
		}

		public void right(Coordinate toMoveTo) {
			int k = 1;
			System.out.println("right update");
			int yDistance = Math.abs(this.top_left.y - toMoveTo.y);
			int y_length = Math.abs(this.top_left.y - this.bottom_right.y) + 1;
			if(y_length == 1) {
				k = 0;
			}
			for(int i = this.bottom_right.y + 1; i < toMoveTo.y + yDistance  + k && i < board[0].length ; i++) {
				for(int j = this.bottom_right.x; j >= this.top_left.x; j--) {
					System.out.println(board[j][i]);
					// board[j][i] = new Coordinate(i,j,Integer.parseInt(this.name));
					if(goals.contains(board[j][i])) {
						board[j][i].setOccupied(true);
						board[j][i].setName(this.name);
					}
					else {
						board[j][i] = new Coordinate(j,i,Integer.parseInt(this.name));
					}
					blocks.put(board[j][i], this);
					blocks.remove(board[j][i - y_length]);
					// System.out.println("remove = " + board[j][i - y_length]);
					if(goals.contains(board[j][i - y_length])) {
						board[j][i - y_length].setOccupied(false);
						board[j][i - y_length].setName("0");
					}
					else {
						board[j][i - y_length] = new Coordinate(j, i - y_length, 0);
					}
				}
			}
		}
		public void printBlocks() {
			Iterator <Map.Entry<Coordinate, Block>> iterator = blocks.entrySet().iterator();
			while(iterator.hasNext()){
				Map.Entry<Coordinate, Block> entry = iterator.next();
				Coordinate key = entry.getKey();
				Block val = entry.getValue();	
			  	// System.out.println("key: " + key + " value: " + val);
			}
		}
		/**
		* @param takes 2 coordinates: the original top left coordinate of the block, and the
		* new top left coordinate we wish to move the block to
		* @result only call and make move when canMakeTrue(...) returns true
		*/

		public void move(Coordinate toMoveTo){
			// if(impossibleMove(toMoveTo)) {
			// 	System.out.println("Contains an impossible move");
			// 	System.out.println("exit(6)");
			// 	System.exit(6);
			// }
			if(canMakeMove(toMoveTo)) {	
				checkGoal();
			}
			else {
				System.out.println("Contains an impossible move");
				System.out.println("exit(6)");
				System.exit(6);
			}
			// checkGoal();
			// System.out.println(canMakeMove(toMoveTo));
		}
		public boolean impossibleMove(Coordinate toMoveTo) {
			
			int x = toMoveTo.getX();
			int y = toMoveTo.getY();
			int xi = this.top_left.x;
			int yi = this.top_left.y;
			boolean legal1 = (x == xi) || (y == yi);
			boolean legal2 = (x < board.length) && (y < board[0].length);
			return !(legal1 && legal2);

		}

		public void checkGoal() {
			int x = 0;
			for(Coordinate a: goals) {
				if(blocks.containsKey(a) && blocks.get(a).isGoal()) {
					x++;
				}
			}
			if(x == goals.size()) {
				System.out.println("REACH ALL YOUR GOALS, DONE");
				System.out.println("exit(0)");
				win = true;
				System.exit(0);
			}
		}

		public boolean isGoal() {
			Coordinate temp = board[this.top_left.x][this.top_left.y];
			// System.out.println("EHRERe");
			// System.out.println("temp = " + temp);
			// System.out.println("tem.getGoal() = " + temp.getGoal());
			if(temp.getGoal() != null) {
				// System.out.println("EHRER222e");
				Block bottom = temp.getGoal();
				return bottom.bottom_right.x == this.bottom_right.x && bottom.bottom_right.y == this.bottom_right.y;
			}
			return false;
		}


		public boolean outOfBoundsCheck(int x, int y) {
			int length = board.length;
			int width = board[0].length;
			return !((x >=0 && x < width) && (y >= 0 && y < length));  
		}

		/** 
		* @return returns the block's top left coordinate
		*/
		public Coordinate getTopLeft() {
			return this.top_left;
		}

		/**
		* @return returns the block's bottom right coordinate
		*/
		public Coordinate getBottomRight(){
			return this.bottom_right;
		}

		/**
		* @return returns the name of the block
		*/
		public String getName(){
			return name;
		}

		public int hashCode() {
			return this.name.hashCode();
			// int x_top = getTop().getX();
			// int y_top = getTop().getY();
			// int x_bottom = getBottom().getX();
			// int y_bottom = getBottom().getY();

			// return (x_top + y_top + x_bottom + y_bottom)*Integer.parseInt(this.name);

		}

		public String toString() {
			return top_left.toString() + ", " + bottom_right.toString();
		}

		public boolean equals(Object o) {
			if (o instanceof Block) {
				Block other = (Block) o;
				boolean legal1 = (this.top_left.x == other.top_left.x && this.top_left.y == other.top_left.y);
				// boolean legal2 = (this.bottom_right.x == other.bottom_right.x && this.bottom_right.y == other.bottom_right.y);
				return legal1;
			}
			return false;
		}

	}
//--------------------Block------------------end----------------------------------------


//--------------------Coordinate------------------begin----------------------------------------
	// public Coordinate

	public class Coordinate {
		private int x;
		private int y;
		private boolean occupied;
		private String name;
		private Block goal = null;


		private Coordinate(int x, int y) {
			// this.name = "Goal";
			this.x = x;
			this.y = y;
		}

		private Coordinate(int x, int y, String name) {
			this.x = x;
			this.y = y;
			this.occupied = false;
			this.name = name;
			if(!name.substring(0,1).equals("0")) {
				this.occupied = true;
			}
		}
		public Coordinate copyCoordinate() {
			return new Coordinate(this.x, this.y, this.name);

		}
		private Coordinate(int x, int y, int i) {
			this.x = x;
			this.y = y;
			this.occupied = false;
			this.name = Integer.toString(i);
			if(i != 0) {
				this.occupied = true;
			}
		}
		public void setGoal(String goal) {
			String[] nums = goal.split("\\s+");
			int n1 = Integer.parseInt(nums[0]);
			int n2 = Integer.parseInt(nums[1]);
			int n3 = Integer.parseInt(nums[0]);
			int n4 = Integer.parseInt(nums[1]);

			// Coordinate top = new Coordinate(Integer.parseInt(goal.substring(0,1)),(Integer.parseInt(goal.substring(2,3))));
			// Coordinate bottom = new Coordinate(Integer.parseInt(goal.substring(4,5)),(Integer.parseInt(goal.substring(6,7))));
			Coordinate top = new Coordinate(n1, n2);
			Coordinate bottom = new Coordinate(n3, n4);
			this.goal = new Block(top, bottom);
		}

		public int getX() {
			return x;
		}
		public int getY() {
			return y;
		}

		public Block getGoal(){
			return this.goal;
		}


		/**
		* @return returns a string that we call hashCode() on
		*/
		public String toString() {
			return this.name + ": " + x + " " + y;
		}

		/**
		* @param takes in an object that we compare this to
		* @return returns true if the two objects have the same coordinates
		*/
		public boolean equals(Object o) {
			Coordinate cast = (Coordinate) o;
			return (this.x == cast.x && this.y == cast.y);
		}

		// public int hashCode(){
		// 	return this.toString().hashCode();
		// }

		/**
		* @param takes a boolean that sets the coordinate's occupation truth value
		* @result sets the coordinate's occupation truth value to the passed in boolean
		*/
		public void setOccupied(boolean occupied){
			this.occupied = occupied;
		}

		public boolean isOccupied(){
			return occupied;
		}

		public String getName(){
			return this.name;
		}

		private void setName(String name) {
			this.name = name;
			
		}

	}

	public class Tray {

		/**
		* @param takes a string that denotes the initial configuration of the tray
		* @result populates the 2D array that represents the board with the blocks
		* passed in by the initial configuration
		*/

		public Tray(String initialConfiguration) {
			try {
				BufferedReader in = new BufferedReader(new FileReader(initialConfiguration));
				int i = 0;
				String current = "";
				Coordinate top_left; //= new Coordinate();
				Coordinate bottom_right;// = new Coordinate();
				Block temp = new Block();
				allBlocks = new HashSet<Block>();
				blocks  = new HashMap<Coordinate, Block>();
				int x ;//= Integer.parseInt(nums[0]);
				int y ;//= Integer.parseInt(nums[1]);
				int k ;//= Integer.parseInt(nums[2]);
				int z ;//= Integer.parseInt(nums[3]);
				while((current = in.readLine()) != null) { 

					String[] nums = current.split("\\s+");
					// System.out.println("nums.length = " + nums.length);
					if(i == 0) {
						int n1 = Integer.parseInt(nums[0]);
						int n2 = Integer.parseInt(nums[1]);
						if(nums.length != 2 && (n1 <= 256 || n2 <= 256)) {
							System.out.println("board dim Must be 2 integer");
							System.out.println("exit(4)");
							System.exit(4);
						}
					}
					else if(nums.length != 4 && i != 0) {
						System.out.println("Tray, Must be 4 integer");
						System.out.println("exit(4)");
						System.exit(4);
					}
					for(int j = 0; j < nums.length ; j++) {
						try {
							int n = Integer.parseInt(nums[j]);
							if(n < 0 || n >= 256) {
								System.out.println("Tray, number must be postive");
								System.out.println("exit(5)");
								System.exit(5);
							}
						} catch (NumberFormatException e) {
							System.out.println("Tray, not a number");
							System.out.println("exit(5)");
							System.exit(5);
						}
					}
					if(i == 0) {
						x = Integer.parseInt(nums[0]);
						y = Integer.parseInt(nums[1]);
						board = new Coordinate[x][y];
						populateBoard();	
						i = 1;
					}
					
				
					else {
						x = Integer.parseInt(nums[0]);
						y = Integer.parseInt(nums[1]);
						k = Integer.parseInt(nums[2]);
						z = Integer.parseInt(nums[3]);
						top_left = new Coordinate(x,y,i);
						bottom_right = new Coordinate(k,z,i);

						// top_left = new Coordinate(Integer.parseInt(current.substring(0,1)),Integer.parseInt(current.substring(2,3)), i);
						// bottom_right = new Coordinate(Integer.parseInt(current.substring(4,5)),Integer.parseInt(current.substring(6,7)), i);
						temp = new Block(top_left, bottom_right, i);
						allBlocks.add(temp);
						updateBoard(temp);
						i++;
					}
					// }

						// System.out.println("current " + i + " = " + current);
				}
			}catch(IOException e) {
				System.err.println("Can't read the file");
				System.out.println("exit(3)");
				System.exit(3);
			}
			// System.out.println("board = " + board.length + " "  + board[0].length);
			// print();
			// System.exit(1);

		}

		public void updateBoard(Block myBlock) {
			int width = Math.abs(myBlock.top_left.x - myBlock.bottom_right.x);
			int length = Math.abs(myBlock.top_left.y - myBlock.bottom_right.y);
			if(width == 0 && length == 0) {
				board[myBlock.top_left.x][myBlock.bottom_right.y].setOccupied(true);
				board[myBlock.top_left.x][myBlock.bottom_right.y].setName(myBlock.getName().substring(0,1));
				blocks.put(board[myBlock.top_left.x][myBlock.bottom_right.y], myBlock);
			}
			else if(width != 0 && length != 0) {
				// System.out.println("length = " + length + ", width = " + width);
				// System.exit(1);
				// for(int i = myBlock.top_left.x; i <= length + myBlock.top_left.x && i < board.length; i++) {
				for(int i = myBlock.top_left.x; i <= myBlock.bottom_right.x && i < board.length; i++) {
					// System.out.println("first");
					for(int j = myBlock.top_left.y; j <= myBlock.bottom_right.y && j < board[0].length; j++) {
						// System.out.println("second");
						board[i][j].setOccupied(true);
						board[i][j].setName(myBlock.getName());
						blocks.put(board[i][j], myBlock);
					}
				}
				// print();
				// System.exit(1);
			}
			else if (width != 0 && length == 0) {
				int i = 0;
				while(i <= width) {
					board[myBlock.top_left.x + i][myBlock.top_left.y].setOccupied(true);
					board[myBlock.top_left.x + i][myBlock.top_left.y].setName(myBlock.getName().substring(0,1));
					blocks.put(board[myBlock.top_left.x + i][myBlock.top_left.y], myBlock);
					i++;
				}
			}
			else if (width == 0 && length != 0) {
				int j = 0;
				while(j <= length) {
					board[myBlock.top_left.x][myBlock.top_left.y + j].setOccupied(true);
					board[myBlock.top_left.x][myBlock.top_left.y + j].setName(myBlock.getName().substring(0,1));
					blocks.put(board[myBlock.top_left.x][myBlock.top_left.y + j], myBlock);
					j++;
				}
			}

		}

		public void populateBoard() {
			for(int i = 0; i < board.length; i++) {
				for(int j = 0; j < board[0].length; j++) {
					board[i][j] =  new Coordinate(i,j,0);
				}
			}
			// System.out.println(board.[5])
		}

		// *
		// * @param takes 2 coordinates: the original top left coordinate of the block, and the
		// * new top left coordinate we wish to move the block to
		// * @result only call and make move when canMakeTrue(...) returns true
		

		// public void move(Coordinate oldTopLeft, Coordinate newTopLeft){
		// 	int yDistance = Math.abs(oldTopLeft.y - newTopLeft.y);
		// 	int xDistance = Math.abs(oldTopLeft.x - newTopLeft.x);
			
			
		// }
		/**
		* @param takes in a move list
		* @result modifies the position of the blocks on the board
		*/
		// public void readMoveList(String moveList){
		
		// }

		/**
		* @param takes in an object to compare this to
		* @result returns equal if this and the object passed in have the same configuration,
		* otherwise returns false
		*/
		// public boolean equals(Object o){
		// 	Tray cast = (Tray) o;
		// 	for(int i = 0; i < board.length; i++){
		// 		for(int j = 0; j < board[i].length; j++){
		// 			if(!board[i][j].equals(cast[i][j])){
		// 				return false;
		// 			}
		// 		}
		// 	}
		// 	return true;
		// }

		// public void print(){
		// 	System.out.println("blocks size  = " + blocks.size());
		// 	for(int i = 0; i < board.length; i++){
		// 		for(int j = 0; j < board[i].length; j++){
		// 				System.out.print( board[i][j].getName() +  "  ");
		// 		}
		// 		System.out.println();
		// 	}
		// }
	}
//--------------------Coordinate------------------begin----------------------------------------


}